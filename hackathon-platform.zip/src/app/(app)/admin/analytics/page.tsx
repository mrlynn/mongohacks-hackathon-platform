import AnalyticsView from "./AnalyticsView";

export default function AnalyticsPage() {
  return <AnalyticsView />;
}

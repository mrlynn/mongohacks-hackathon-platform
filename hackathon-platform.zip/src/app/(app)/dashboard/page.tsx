import DashboardClient from "./DashboardClient";

export default function DashboardPage() {
  return <DashboardClient />;
}
